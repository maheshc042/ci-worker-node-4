# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `735`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-08 01:47:24 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **3** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **14** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **5** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **24** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-071126008934` | **Infinity Automated Solutions** | Automation Engineer | 3.0-8.0y | 5.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-071126008934) |
| `reco-051126924297` | **Starworth Global Solutions** | Quality Analyst | 3.0-3.0y | 2.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-051126924297) |
| `reco-041126015828` | **A client of sarthee consultancy** | Executive Quality Assurance | 3.0-8.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126015828) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-061126502072` | **QAD** | Sr. QA Engineer, AI Agents & Agentic Workflows | [Apply on Company Site](https://jobs.smartrecruiters.com/QADInc/744000159858895) |
| `reco-051126501405` | **Vanguard Technologies** | QA Engineer, Specialist / Sr Software Development Engineer in Test | [Apply on Company Site](https://www.vanguardjobs.com/job/24107669/quality-assurance-engineer-specialist-senior-software-development-engineer-in-test-sdet-hyderabad-in/) |
| `reco-061126500524` | **Mariox Software** | QA Automation Engineer | [Apply on Company Site](https://www.marioxsoftware.com/careers#roles) |
| `reco-051126501852` | **Greedygame Media** | Manual QA Engineer - Web Applications & Dashboard | [Apply on Company Site](https://app.pyjamahr.com/careers?company=blinkdigital&job_id=425072&company_uuid=62673CED1A) |
| `reco-061126502583` | **Iqvia Biotech** | QA Automation Engineer | [Apply on Company Site](https://iqvia.wd1.myworkdayjobs.com/en-US/IQVIA/job/Kochi-India/QA-Automation-Engineer_R1571699?Location_Country=c4f78be1a8f14da0ab49ce1162348a5e) |
| `reco-061126502078` | **Formula Group** | Automation Testing Professional | [Apply on Company Site](https://www.formulaindia.com/careers/) |
| `reco-061126502079` | **Onit** | Quality Assurance Engineer - Playwright | [Apply on Company Site](https://jobs.lever.co/onit/6d9de478-7e5e-465f-9627-675538f04557) |
| `reco-051126500899` | **WMS Gaming** | Associate QA Engineer, Software | [Apply on Company Site](https://lnw.wd5.myworkdayjobs.com/en-US/LightWonderExternalCareers/job/Bangalore-India/Associate-QA-Engineer--Software_R322807?locationCountry=c4f78be1a8f14da0ab49ce1162348a5e) |
| `reco-041126501572` | **Deepintent** | Sr Software Engineer In Test | [Apply on Company Site](https://job-boards.greenhouse.io/deepintent/jobs/6240438004) |
| `reco-061126500884` | **TO THE NEW** | Software Engineer - AEC | [Apply on Company Site](https://www.tothenew.com/careers/software_engineer_aec) |
| `reco-061126501024` | **Nest Digital** | Test Engineer | [Apply on Company Site](https://careers.nestdigital.com/apply?job=2790) |
| `reco-041126503656` | **Arvind Limited** | Tester | [Apply on Company Site](https://arvind.darwinbox.in/ms/candidatev2/main/careers/jobDetails/a6ae99c7fd0bf2) |
| `reco-041126500176` | **Sutherland** | OS Test engineer | [Apply on Company Site](https://jobs.smartrecruiters.com/Sutherland/744000159312049) |
| `reco-041126501811` | **Prescient Automation** | Testing Engineer | [Apply on Company Site](https://www.prescientautomation.com/careers/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-030826019331` | **Solytics Partners** | Senior Software Engineer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `reco-061126026507` | **Altisource** | QA Engineer ( AI & Automation Testing) | `already_applied` | Already applied marker observed on verify pass |
| `reco-051126037933` | **Mitratech India** | Software Engineer II | `already_applied` | Already applied marker observed on verify pass |
| `reco-051126036044` | **Talent Corner HR Services** | Junior Software Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-050826036146` | **Hasman Software Solutions** | AI Consultant | `filter_title` | title 'AI Consultant' lacks required role keywords from title_must_include_any |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-071126007086` | **Client of R M Shah Management Consultants** | Automation Engineer For Robot Division | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-735/014200_608518_Full-Stack-Web-Developer_reco-071126007086_unanswered.png) |
| `reco-051126014902` | **Bold Technology Systems** | Sdet Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-735/014718_328177_Full-Stack-Web-Developer_reco-051126014902_unanswered.png) |
