# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `708`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-05 16:52:43 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **7** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **10** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **8** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **6** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **31** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-041126016647` | **Sequretek It Solutions** | Python Developer | 1.0-0y | 3.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-041126016647) |
| `reco-031126928755` | **Capgemini** | SDET Automation Testing | 3.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-031126928755) |
| `reco-041126910438` | **Agilysis** | AI Agent Developer | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126910438) |
| `reco-041126502057` | **Trigyn Technologies** | AI Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126502057) |
| `reco-051126026551` | **Tagbin Services** | Artificial Intelligence Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126026551) |
| `reco-041126022080` | **Radiant Digital Solutions** | Artificial Intelligence Engineer | 3.0-7.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126022080) |
| `reco-051126503011` | **PIT Solutions** | MS Fabric Data and SQL Engineer | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126503011) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-051126503235` | **Dexaminds** | AI/ML Engineer | [Apply on Company Site](https://dexaminds.com/careers/ai-ml-engineer/) |
| `reco-051126503146` | **Voicegate Technologies India** | Full Stack Developer ? MERN / Python Stack | [Apply on Company Site](https://www.naukri.com/job-listings-051126503146) |
| `reco-051126500628` | **Clobrix Technologies** | AI / ML Engineer | [Apply on Company Site](https://clobrix.com/careers) |
| `reco-051126502155` | **AMERICAN EXPRESS** | Sr Analyst - Data Governance (GenAI) | [Apply on Company Site](https://egug.fa.us2.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1/job/26016002) |
| `reco-031126502575` | **Global Business Ser 4u** | Azure AI ML-Remote Professional | [Apply on Company Site](https://gbs4u.com/career_gbs4u/?job_id=z5G7h3l6a1kMvyS65NP3c_znHbNi4sIZMjuBhKE9SSU=) |
| `reco-021126500890` | **Concord Usa** | AI Developer | [Apply on Company Site](https://concordusa.applytojob.com/apply/BOHXG4iF3Y/AI-Developer) |
| `reco-031126501513` | **Atos** | AGENTIC AI ENGINEER | [Apply on Company Site](https://jobs.atos.net/job/Chennai-AGENTIC-AI-ENGINEER/1453259933) |
| `reco-041126503158` | **Sii Polska** | Data Analyst (f/m/x) | [Apply on Company Site](https://sii.pl/en/job-ads/id/38549/data-analyst-f-m-x/) |
| `reco-041126503103` | **Bottom Line** | Senior Database Engineer I | [Apply on Company Site](https://job-boards.greenhouse.io/bottomlinetechnologies/jobs/8909168002) |
| `reco-041126501806` | **Prescient Automation** | Sr. Automation Engineer | [Apply on Company Site](https://www.prescientautomation.com/careers/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-051126022288` | **Celebal Technologies** | Ai ML Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-101125007285` | **Fibe** | Python Developer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `reco-041126501434` | **Nrd Tech** | AI QA Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `reco-051126023586` | **Quest Global** | Azure Data Engineer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `reco-031126021745` | **SHL** | Senior AI Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-081026050971` | **Yabx** | Artificial Intelligence Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-071026010344` | **Centific** | Automation Test Engineer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `reco-041126500244` | **Happiest Minds Technologies** | Sr TEST ENGINEER - Automation testing | `filter_experience` | requires 5.0y > ceiling 3.5y |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-041126014208` | **Hiringhood** | AI Innovation & Prototyping Engineer (GenAI / Agentic AI) | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-708/164030_687142_AI-Python-Engineer_reco-041126014208_unanswered.png) |
| `reco-031126028563` | **Datamatics** | Hiring AI & LLM Engineer with Datamatics For Mumbai/Bangalore | `failed` | Chatbot error: drawer open but no question detected after 3 checks (unknown widget) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-708/164100_748846_AI-Python-Engineer_reco-031126028563_chatbot-error.png) |
| `reco-021126015531` | **Info Edge** | GEN AI - SDET Automation Test Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-708/164456_194142_AI-Python-Engineer_reco-021126015531_unanswered.png) |
| `reco-031126011968` | **R Systems International** | Automation QA Engineer (WebdriverIO) | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-708/164723_253881_AI-Python-Engineer_reco-031126011968_unanswered.png) |
| `reco-031126021660` | **Cigna** | Automation Test Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-708/165151_343817_AI-Python-Engineer_reco-031126021660_unanswered.png) |
| `reco-031126021660` | **Cigna** | Automation Test Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-708/165237_773320_AI-Python-Engineer_reco-031126021660_unanswered.png) |
