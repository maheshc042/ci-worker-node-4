# 🎯 Application Run Report: Instahyre (Instahyre Unified (AI & Full Stack))

- **Run ID:** `708`
- **Platform:** Instahyre
- **Profile:** Instahyre Unified (AI & Full Stack)
- **Generated At:** 2026-11-05 17:03:31 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **5** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **5** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `instahyre-h-b060c3dd8e6013f720df` | **Google** | QA Engineer - TypeScript & Playwright | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-e7e26305b5d4fdc22422` | **Airtel X Labs** | Data Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-fc30f033bde68403b903` | **The Agency Fund** | Forward Deployed Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-9f125d118d80c75fbf93` | **Zavo** | SDET 1 | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-bed232fc56d2f7dd8ceb` | **Rocketlane** | Forward Deployed Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
