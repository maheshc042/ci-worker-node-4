# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `709`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-05 17:26:03 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **3** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **13** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **2** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **3** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **21** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-051126026717` | **Heeraji Fashion Llp** | Fullstack Developer | 3.0-5.0y | 6.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-051126026717) |
| `reco-051126022649` | **Sadguru Healthcare Services** | Software Engineer | 2.0-7.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126022649) |
| `reco-051026930549` | **Iris Software** | Devops - Engineer | 3.0-7.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051026930549) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-051126502733` | **Tzar Digital Agency** | Full Stack Developer | [Apply on Company Site](https://www.tzar.co/career) |
| `reco-051126502119` | **Cloudesign** | MERN Stack Developer | [Apply on Company Site](https://cloudesign.keka.com/careers/jobdetails/114755) |
| `reco-051126503159` | **Mahendra Technosoft** | Full Stack Developer | [Apply on Company Site](https://www.mahendratechnosoft.com/careers) |
| `reco-051126501096` | **Quarks Technosoft** | ReactJS Developer SDEII | [Apply on Company Site](https://www.qtsolv.com/career-details/?jobid=1865) |
| `reco-051126503050` | **Microsive** | Back-End Developer | [Apply on Company Site](https://www.microsive.com/careers/back-end-developer) |
| `reco-051126500497` | **DIATOZ Solutions** | Node.JS Developer | [Apply on Company Site](https://careers.diatoz.com/jobs/DIATOZ%20Solutions%20Pvt%20Ltd./0ccf0e60-1ca1-4a11-8a52-a0181be516cf) |
| `reco-051126500624` | **VR Della Infotech** | Full Stack Developer | [Apply on Company Site](https://www.vrdella.com/career.html?region=in) |
| `reco-051126502717` | **Digiink Solutions** | Full Stack Developer | [Apply on Company Site](https://www.digiinksolutions.com/careers) |
| `reco-051126502289` | **Avaloq** | Software Engineer (Fullstack) | [Apply on Company Site](https://www.avaloq.com/careers/job-openings/software-engineer-fullstack-pune-744000159594599) |
| `reco-051126501198` | **TekWissen** | FullStack Developer | [Apply on Company Site](https://tekwissen.com/career/india/?job_id=z5G7h3l6a1kMvyS65NP3c5Jsio1JGhAWz73p9mycHRE%3D) |
| `reco-041126501567` | **Knowledgesprint Technologies** | Software Engineer | [Apply on Company Site](https://knowledgesprint.com/careers) |
| `reco-041126500887` | **Legato** | Testing- QA Engineer | [Apply on Company Site](https://elevancehealth.wd1.myworkdayjobs.com/en-US/carelonglobal_in/job/IND-KA-Bengaluru-Bagmane-Solarium-City/Testing--QA-Engineer--BF--40489-75364--JR210193_JR210193) |
| `reco-051126501749` | **Xylem Water Solutions** | Software Engineer | [Apply on Company Site](https://xylem.wd5.myworkdayjobs.com/en-US/xylem-careers/job/Vadodara-73-East-Ave/Software-Engineer_R51402-1) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-051126024659` | **Premium Client Company- Email CV at hr@maxicarrow.com WhatsApp -+91-7011784220, +91-7011391736,** | Fullstack Developer | `already_applied` | Already applied marker observed on verify pass |
| `reco-021126024490` | **Neurealm** | Walk-in || Automation Tester | `stale_job` | Expired posting detected at classification (no apply machinery on page) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-051126012288` | **Fulcrum Worldwide Software** | Senior React JS Developer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-709/171751_648331_Full-Stack-Web-Developer_reco-051126012288_unanswered.png) |
| `reco-271026018378` | **Dbiz.ai** | Qa Engineer | `failed` | Apply dialog never opened (click had no page effect) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-709/172518_045123_Full-Stack-Web-Developer_reco-271026018378_dialog-never-opened.png) |
| `reco-081026042298` | **Intellect Design Arena** | Devops Engineer | `failed` | Apply dialog never opened (click had no page effect) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-709/172558_636997_Full-Stack-Web-Developer_reco-081026042298_dialog-never-opened.png) |
