# 🎯 Application Run Report: Cutshort (Cutshort Unified (AI & Full Stack))

- **Run ID:** `708`
- **Platform:** Cutshort
- **Profile:** Cutshort Unified (AI & Full Stack)
- **Generated At:** 2026-11-05 16:57:27 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **1** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **1** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **2** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `cutshort-JS1ppdol` | **Ungrammary** | Full Stack Developer (MERN) | 2.0-0y | 5.0 LPA | 1-click | [View Posting](https://cutshort.io/job/Full-Stack-Developer-MERN-Ungrammary-JS1ppdol) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `cutshort-jl06tTln` | **Cutshort Lightning** | Senior Backend Engineer (Python) | `filter_experience` | requires 4.0y > ceiling 3.5y |
