# 🎯 Application Run Report: Linkedin (AI / Python Engineer)

- **Run ID:** `753`
- **Platform:** Linkedin
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-10 03:13:11 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **1** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **2** | | |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4489123496` | **Straive** | Generative AI Engineer | `filter_experience` | dedicated AI/ML role requires 5.0y > candidate's 3y AI experience (recruiter will reject) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4487643273` | **BestEx Research** | Quant Data Engineer- | `unanswered_question` | Easy Apply step blocked (5 questions): Required field unfilled - step=inputs:15::Apply to BestEx Research 2/6 pages Resume* Select or upload a resume in DOC, DOCX, or PDF format that is less than 2MB PDF CV_Mahesh_Chitakoti_2026_1_.pdf 11/10/2026 PDF CV_Mahesh_Chitakoti_2026.pdf 11/10/2026 Upload resume Headline 79/127 79 of 127  | None |
