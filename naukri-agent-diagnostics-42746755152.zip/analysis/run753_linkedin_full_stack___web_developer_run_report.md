# 🎯 Application Run Report: Linkedin (Full Stack / Web Developer)

- **Run ID:** `753`
- **Platform:** Linkedin
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-10 03:10:43 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **2** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4487942897` | **Appzlogic** | Backend developer - Xml ,Marklogic | `unanswered_question` | LinkedIn screening needs a verified answer | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-10/run-753/030945_687893_Full-Stack-Web-Developer_linkedin-4487942897_linkedin-screening-review.png) |
| `linkedin-4444361181` | **Energy Exemplar** | Software Engineer (Full Stack) | `unanswered_question` | Easy Apply step blocked (1 questions): Required field unfilled - step=inputs:1::Apply to Energy Exemplar 4/5 pages Additional Questions Energy Exemplar has my consent to collect, store, and process my data for the purpose of considering me for employment, and for up to 365 days thereafter.* Yes This field is required Back Review | None |
