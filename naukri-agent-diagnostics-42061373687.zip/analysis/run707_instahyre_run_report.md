# 🎯 Application Run Report: Instahyre (Instahyre Unified (AI & Full Stack))

- **Run ID:** `707`
- **Platform:** Instahyre
- **Profile:** Instahyre Unified (AI & Full Stack)
- **Generated At:** 2026-11-05 16:12:28 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **1** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **5** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **6** | | |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `instahyre-h-02bbbd2193c834ad8a48` | **Meesho** | Backend Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `instahyre-h-aed274fcf1910ec6b168` | **Snabbit** | Full Stack Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-4eb16ef36070b8538d17` | **Swiggy** | SDE 2 (Frontend) | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-a9ba8a2442d0ef29fd46` | **Anaira AI** | Full - Stack Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-fb5a000e03502e49eb38` | **Neoqubit** | LLM Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
| `instahyre-h-3876dedc6abfe098e778` | **Kaleidofin** | AI Engineer | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | None |
