# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `702`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-05 09:51:00 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **10** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Enqueued** | **11** | 🌐 Handed Off | Career site links enqueued to Sidekick external queue |
| **Skipped** | **11** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **3** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **35** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-041126910340` | **Wits Innovation Lab** | QA Automation | 3.0-8.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126910340) |
| `reco-041126017483` | **Randstad Digital** | Backend Developer | 2.0-7.0y | 11.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-041126017483) |
| `reco-041126910581` | **Wits Innovation Lab** | QA Automation Engineer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126910581) |
| `reco-031126913563` | **Cornerstone** | Software Engineer | 3.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-031126913563) |
| `reco-041126022239` | **gen Z Solutions** | Automation Test Engineer | 3.0-5.0y | 3.25 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-041126022239) |
| `reco-041126009500` | **Vlink** | Devops Engineer | 3.0-6.0y | 3.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-041126009500) |
| `reco-041126027461` | **R1 RCM** | Hiring For Software Engineer | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126027461) |
| `reco-041126025187` | **Toshiba Software India** | Python Software Developer | 2.0-7.5y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126025187) |
| `reco-041126027875` | **Xevyte Technologies** | Software Engineer | 3.0-7.0y | 5.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-041126027875) |
| `reco-031126028663` | **Jags Consulting Services Chennai** | Test Engineer | 0-3.0y | 3.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-031126028663) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-041126503098` | **Perfectiongeeks Technologies** | MERN Stack Developer | [Apply on Company Site](https://www.perfectiongeeks.com/career/mern-stack-developer) |
| `reco-041126503095` | **Perfectiongeeks Technologies** | Full Stack Developer | [Apply on Company Site](https://www.perfectiongeeks.com/career/full-stack-developer) |
| `reco-041126501895` | **Varaha Systems** | Software Engineer - Frontend | [Apply on Company Site](https://jobs.pitchnhire.com/varaha.com/software-engineer-frontend-9F0i1/019e3f66-72c1-73b5-b780-06c1c39cddd1) |
| `reco-041126500881` | **Electrocom Software** | Sr Software Engineer | [Apply on Company Site](https://www.easyofficesoftware.com/career) |
| `reco-041126501473` | **Target** | Engineer - Backend with Gen Ai | [Apply on Company Site](https://target.wd5.myworkdayjobs.com/en-US/targetcareers/job/L4-Manyata-Embassy-Business-Park-Racenahali--Nagawara-Villages-Outer-Ring-Rd-Bangalore-540065/Engineer---Backend-with-Gen-Ai_R0000479586?redirect=/targetcareers/userHome&Location_Country=c4f78be1a8f14da0ab49ce1162348a5e) |
| `reco-041126501050` | **Nest Digital** | Software Engineer - Cloud Services | [Apply on Company Site](https://careers.nestdigital.com/apply?job=2757) |
| `reco-021126502761` | **Global Business Ser 4u** | UI/UX developer | [Apply on Company Site](https://gbs4u.com/career_gbs4u/?job_id=z5G7h3l6a1kMvyS65NP3c267YjQ0IIKubTiXPbhIsIw=) |
| `reco-041126500776` | **Verisk** | Sr SDET I | [Apply on Company Site](https://fa-ewmy-saasfaprod1.fa.ocs.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1/job/5098) |
| `reco-041126501930` | **Copeland** | Software Engineer | [Apply on Company Site](https://copeland.wd5.myworkdayjobs.com/en-US/Copeland_External_Careers_Page/job/Pune-India/Software-Engineer_JR119136) |
| `reco-041126501021` | **Cin7** | Software Engineer | [Apply on Company Site](https://www.naukri.com/job-listings-041126501021) |
| `reco-041126500950` | **Onemagnify** | Sr Test Engineer | [Apply on Company Site](https://onemagnify.wd5.myworkdayjobs.com/OneMagnify_Careers/job/Senior-Test-Engineer_R2358) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-041126012675` | **Utrade Solutions** | Fullstack Web Developer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126025717` | **PM AM Corporation** | Artificial Intelligence Engineer - Full Stack | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126022992` | **Fortunesoft It Innovations** | QA Automation Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126013737` | **Mindful Gurukul** | Fullstack Developer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `reco-031126017423` | **Hitachi** | Fullstack Developer | `already_applied` | Already applied marker observed on verify pass |
| `reco-021126014488` | **Kaaliber** | QA Automation Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126022917` | **Anmeda Systems** | Qa Test Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126910450` | **Wits Innovation Lab** | QA Automation | `daily_cap` | company daily cap reached (wits innovation lab, max 2/day) |
| `reco-031126024001` | **Qualitykiosk Technologies** | Senior Automation Engineer ( Selenium) | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126021351` | **IDEMIA Public Security** | Site Reliability Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-050826036146` | **Hasman Software Solutions** | AI Consultant | `filter_title` | title 'AI Consultant' lacks required role keywords from title_must_include_any |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-301025014443` | **Blackstraw Technologies** | Python Software Developer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-702/094029_354423_Full-Stack-Web-Developer_reco-301025014443_unanswered.png) |
| `reco-041126022218` | **Opentext** | Quality Assurance Developer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-702/094415_263279_Full-Stack-Web-Developer_reco-041126022218_unanswered.png) |
| `reco-021126015531` | **Info Edge** | GEN AI - SDET Automation Test Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-702/094531_609291_Full-Stack-Web-Developer_reco-021126015531_unanswered.png) |
