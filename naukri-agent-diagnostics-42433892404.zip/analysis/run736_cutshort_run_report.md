# 🎯 Application Run Report: Cutshort (Cutshort Unified (AI & Full Stack))

- **Run ID:** `736`
- **Platform:** Cutshort
- **Profile:** Cutshort Unified (AI & Full Stack)
- **Generated At:** 2026-11-08 02:10:54 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **2** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **2** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `cutshort-qio9oThz` | **Proximity Works** | VOD Consultant Backend (Python/Go) Onsite BLR, 6 Month Contract | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://cutshort.io/job/VOD-Consultant-Backend-Python-Go-Onsite-BLR-6-Month-Contract-Bengaluru-Bangalore-Proximity-Works-qio9oThz) |
| `cutshort-eFgyYgNN` | **NeoGenCode Technologies Pvt Ltd** | AWS Data Engineer / Data Lake Engineer | 2.0-4.0y | 3.0 LPA | 1-click | [View Posting](https://cutshort.io/job/AWS-Data-Engineer-Data-Lake-Engineer-Gurugram-NeoGenCode-Technologies-Pvt-Ltd-eFgyYgNN) |
