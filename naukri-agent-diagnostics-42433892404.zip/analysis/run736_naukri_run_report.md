# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `736`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-08 02:06:12 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **5** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **5** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-061126009900` | **CGI** | Python developer | `failed` | Page classification failed: Apply button not resolvable within SLA - url=https://www.naukri.com/job-listings-061126009900 | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-736/020457_550064_AI-Python-Engineer_reco-061126009900_open-failed.png) |
| `reco-061126919151` | **Soul Ai** | GenAI Engineer | `failed` | Page classification failed: Apply button not resolvable within SLA - url=https://www.naukri.com/job-listings-061126919151 | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-736/020515_260313_AI-Python-Engineer_reco-061126919151_open-failed.png) |
| `reco-210826038174` | **Synapseindia** | Sr. Software Engineer (AI ML) | `failed` | Page classification failed: Apply button not resolvable within SLA - url=https://www.naukri.com/job-listings-210826038174 | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-736/020532_754467_AI-Python-Engineer_reco-210826038174_open-failed.png) |
| `reco-051126500014` | **Elsevier** | AI Platform Engineer III | `failed` | Page classification failed: Apply button not resolvable within SLA - url=https://www.naukri.com/job-listings-051126500014 | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-736/020550_493087_AI-Python-Engineer_reco-051126500014_open-failed.png) |
| `reco-051126503044` | **Parkar Global Technologies** | Senior AI Engineer | `failed` | Page classification failed: Apply button not resolvable within SLA - url=https://www.naukri.com/job-listings-051126503044 | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-736/020607_952294_AI-Python-Engineer_reco-051126503044_open-failed.png) |
