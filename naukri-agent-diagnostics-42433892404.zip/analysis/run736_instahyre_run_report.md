# 🎯 Application Run Report: Instahyre (Instahyre Unified (AI & Full Stack))

- **Run ID:** `736`
- **Platform:** Instahyre
- **Profile:** Instahyre Unified (AI & Full Stack)
- **Generated At:** 2026-11-08 02:27:16 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **14** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **15** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `instahyre-450127` | **nCircle Tech** | AI-Enabled MERN Stack Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450138` | **Salesforce** | Full-Stack Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450289` | **HCLTech** | Technical Specialist - JavaScript, React.js | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450240` | **Equinix** | Software Development Engineer Intermediate | 1.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450393` | **PowerSchool** | Software Engineer 2 | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450323` | **Hitachi** | Software Development Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450419` | **TriNet** | Associate Software Engineer | 2.0-2.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450386` | **Deepintent** | Software Engineer | 1.5-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450505` | **Microsoft** | Software Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450345` | **Hitachi Vantara** | Software Development Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450140` | **Havas** | Integration and Application Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450485` | **Cisco** | Software Engineer | 1.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450464` | **Xylem** | Software Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-450530` | **Ford Motors** | Partner IAM - Security Platform Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `instahyre-450514` | **PricewaterhouseCoopers (PwC)** | Generative AI - Associate 2 | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-08/run-736/022348_812578_Instahyre-Unified-AI-Full-Stack_instahyre-450514_instahyre-submit-unconfirmed.png) |
