# 🎯 Application Run Report: Linkedin (Full Stack / Web Developer)

- **Run ID:** `754`
- **Platform:** Linkedin
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-10 04:31:03 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **2** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **4** | | |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4487988714` | **QuantumCommit** | 🚀 WE ARE HIRING | SDE – FRONTEND | REACT.JS | TYPESCRIPT | AWS | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4487987715` | **QuantumCommit** | BACKEND | NODE.JS | TYPESCRIPT | `filter_experience` | requires 8.0y > ceiling 3.5y |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4444361181` | **Energy Exemplar** | Software Engineer (Full Stack) | `unanswered_question` | Easy Apply step blocked (1 questions): Required field unfilled - step=inputs:1::Apply to Energy Exemplar 4/5 pages Additional Questions Energy Exemplar has my consent to collect, store, and process my data for the purpose of considering me for employment, and for up to 365 days thereafter.* Yes This field is required Back Review | None |
| `linkedin-4487942897` | **Appzlogic** | Backend developer - Xml ,Marklogic | `failed` | LinkedIn did not expose a verifiable application route | None |
