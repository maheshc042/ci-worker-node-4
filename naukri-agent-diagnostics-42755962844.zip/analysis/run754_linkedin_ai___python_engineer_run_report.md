# 🎯 Application Run Report: Linkedin (AI / Python Engineer)

- **Run ID:** `754`
- **Platform:** Linkedin
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-10 04:32:25 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **0** | | |
