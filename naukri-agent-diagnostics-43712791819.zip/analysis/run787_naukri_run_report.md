# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `787`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-15 12:30:43 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **3** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **1** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **6** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-131126030774` | **Infosys** | Gen AI, LLM Consultant | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-131126030774) |
| `reco-111126930765` | **Forward Eye Technologies** | Python Developer - Data Structure & Algorithm | 1.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-111126930765) |
| `reco-121126918900` | **Twixor** | Chatbot Developer | 1.0-1.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-121126918900) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-131126008684` | **Valuelabs** | Azure Devops Engineer | `already_applied` | Already applied marker observed on verify pass |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-131126032606` | **Quest Global** | Devops Engineer-Quest Global-Trivendrum | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/122858_542927_AI-Python-Engineer_reco-131126032606_unanswered.png) |
| `reco-131126033607` | **Hiring for Infosys** | Infosys Hiring For Gen AI Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/123038_320302_AI-Python-Engineer_reco-131126033607_unanswered.png) |
