# 🎯 Application Run Report: Linkedin (Full Stack / Web Developer)

- **Run ID:** `787`
- **Platform:** Linkedin
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-15 12:33:57 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **5** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **5** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4490204455` | **WSI ALM** | Backend Focused Full Stack Developer - Next.js Expertise | `failed` | LinkedIn served a signed-out listing | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/123300_297081_Full-Stack-Web-Developer_linkedin-4490204455_linkedin-detail-unavailable.png) |
| `linkedin-4489355654` | **NeuroDrift** | Full-Stack Developer | `failed` | LinkedIn served a signed-out listing | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/123313_780277_Full-Stack-Web-Developer_linkedin-4489355654_linkedin-detail-unavailable.png) |
| `linkedin-4446744290` | **EXL** | Associate - Business Analyst-Application Development-Backend Development | `failed` | LinkedIn served a signed-out listing | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/123327_184789_Full-Stack-Web-Developer_linkedin-4446744290_linkedin-detail-unavailable.png) |
| `linkedin-4480823519` | **Securin Inc.** | Agentic Full-Stack Engineer | `failed` | LinkedIn served a signed-out listing | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/123340_680532_Full-Stack-Web-Developer_linkedin-4480823519_linkedin-detail-unavailable.png) |
| `linkedin-4490210616` | **Zetheta Algorithms Private Limited** | Full Stack Engineer | `failed` | LinkedIn served a signed-out listing | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/123354_204967_Full-Stack-Web-Developer_linkedin-4490210616_linkedin-detail-unavailable.png) |
