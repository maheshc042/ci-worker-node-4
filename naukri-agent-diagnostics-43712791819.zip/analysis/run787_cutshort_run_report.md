# 🎯 Application Run Report: Cutshort (Cutshort Unified (AI & Full Stack))

- **Run ID:** `787`
- **Platform:** Cutshort
- **Profile:** Cutshort Unified (AI & Full Stack)
- **Generated At:** 2026-11-15 12:42:26 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **4** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **4** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `cutshort-IGxTMLzy` | **Euphoric Thought Technologies** | MERN Developer (Contract Base Immediate joiner ) | `failed` | Cutshort could not verify the selected Full Stack Engineer résumé (waiting for Cutshort to display the uploaded filename) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/124122_362468_Cutshort-Unified-AI-Full-Stack_cutshort-IGxTMLzy_cutshort-resume-unverified.png) |
| `cutshort-P3uS7fK3` | **Euphoric Thought Technologies** | MERN Stack Developer | `failed` | Cutshort could not verify the selected Full Stack Engineer résumé (waiting for Cutshort to display the uploaded filename) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/124146_586596_Cutshort-Unified-AI-Full-Stack_cutshort-P3uS7fK3_cutshort-resume-unverified.png) |
| `cutshort-l0pPTpn6` | **Talent Teams** | Software Developer | `failed` | Cutshort could not verify the selected Full Stack Engineer résumé (waiting for Cutshort to display the uploaded filename) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/124210_775974_Cutshort-Unified-AI-Full-Stack_cutshort-l0pPTpn6_cutshort-resume-unverified.png) |
| `cutshort-TokFxfrA` | **Cglia Solutions LLP** | Software Engineer - Angular | `failed` | Cutshort pitch dialog did not identify Software Engineer - Angular at Cglia Solutions LLP | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-787/124221_855481_Cutshort-Unified-AI-Full-Stack_cutshort-TokFxfrA_cutshort-pitch-heading-mismatch.png) |
