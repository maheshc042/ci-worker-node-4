# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `716`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-06 06:00:40 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **7** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **7** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **8** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **4** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **26** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-041126025531` | **Infosys** | Gen AI, LLM | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126025531) |
| `reco-051126931371` | **Infosys** | Gen Ai, LLM Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126931371) |
| `reco-051126936972` | **Jero Technologies** | Agentic AI Automation Engineer | 2.0-7.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126936972) |
| `reco-051126029045` | **Steel Manufacturing** | Data Engineer | 3.0-6.0y | 5.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-051126029045) |
| `reco-051126027398` | **Tagbin Services** | Junior AI Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126027398) |
| `reco-041126022072` | **Moveinsync Technology Solutions** | Data Analyst | 1.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-041126022072) |
| `reco-051126926708` | **AtkinsRéalis** | Water Quality Analyst/Modeller | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126926708) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-051126502881` | **E4 Software Services** | Python & AI Application Developer (LLM / GenAI) | [Apply on Company Site](https://ats24.e4softwares.com/career/CareerDetails1?id=3eGeDbF175746f) |
| `reco-051126502419` | **Acenet** | AI Engineer | [Apply on Company Site](https://acenet.io/careers?job_id=z5G7h3l6a1kMvyS65NP3c39KKXQWmSUGd-NRRX3GZFc=) |
| `reco-051126502456` | **Ashok Maheshwary & Associates** | AI Automation Engineer | [Apply on Company Site](https://www.akmglobal.com/careers/) |
| `reco-051126502578` | **Milestone Technologies** | Sr Analytics Engineer | [Apply on Company Site](https://phf.tbe.taleo.net/phf01/ats/careers/v2/viewRequisition?org=COVESTIC2&cws=37&rid=14327) |
| `reco-041126503212` | **Platinumrx** | Senior Data Analyst | [Apply on Company Site](https://platinumrx.keka.com/careers/jobdetails/94513) |
| `reco-051126911391` | **Wells Fargo** | Senior Artificial Intelligence Solutions Consultant | [Apply on Company Site](https://wd1.myworkdaysite.com/en-US/recruiting/wf/WellsFargoJobs/job/Hyderabad-India/Senior-Artificial-Intelligence-Solutions-Consultant_R-584427) |
| `reco-041126502278` | **nVent** | ISC Data Analyst | [Apply on Company Site](https://nvent.wd5.myworkdayjobs.com/en-US/nVent/job/Bangalore-IN/ISC-Data-Analyst_R24281) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-051126038593` | **Broadridge** | Python with Gen AI Developer | `already_applied` | Already applied marker observed on verify pass |
| `reco-051126036089` | **Exponentia.ai Private Limited** | Data Engineer/ AI Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126021688` | **SKAAS** | AI / ML Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-061126000124` | **X C S is recrting for it client an IT Consulting firm** | Artificial Intelligence Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-031126013707` | **Endeavour Consultancy Services And Solutions** | ADG Analyst (Data Engineer) | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126027337` | **Nityo Infotech** | Artificial Intelligence Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126029484` | **Coforge** | Data Analyst | `already_applied` | Already applied marker observed on verify pass |
| `reco-031126021660` | **Cigna** | Automation Test Engineer | `already_applied` | Already applied marker observed on verify pass |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-031126028563` | **Datamatics** | Hiring AI & LLM Engineer with Datamatics For Mumbai/Bangalore | `failed` | Chatbot error: drawer open but no question detected after 3 checks (unknown widget) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-716/054929_470834_AI-Python-Engineer_reco-031126028563_chatbot-error.png) |
| `reco-051126038635` | **Neutrinoiq** | AI Engineer FinTech SaaS | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-716/055036_622761_AI-Python-Engineer_reco-051126038635_unanswered.png) |
| `reco-051126037899` | **Crossing Hurdles** | Data Analyst | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-716/055145_385977_AI-Python-Engineer_reco-051126037899_unanswered.png) |
| `reco-051126013372` | **Mantraa Advisory Service** | GTM Automation Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-716/055801_640543_AI-Python-Engineer_reco-051126013372_unanswered.png) |
