# 🎯 Application Run Report: Cutshort (Cutshort Unified (AI & Full Stack))

- **Run ID:** `721`
- **Platform:** Cutshort
- **Profile:** Cutshort Unified (AI & Full Stack)
- **Generated At:** 2026-11-06 08:03:04 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **1** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **3** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `cutshort-2ZWD0fBS` | **Techjays** | AI Engineer | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://cutshort.io/job/AI-Engineer-Coimbatore-Techjays-2ZWD0fBS) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `cutshort-qio9oThz` | **Proximity Works** | VOD Consultant Backend (Python/Go) Onsite BLR, 6 Month Contract | `failed` | Cutshort could not verify the selected Full Stack Engineer résumé | None |
| `cutshort-eFgyYgNN` | **NeoGenCode Technologies Pvt Ltd** | AWS Data Engineer / Data Lake Engineer | `failed` | Cutshort could not verify the selected Full Stack Engineer résumé | None |
