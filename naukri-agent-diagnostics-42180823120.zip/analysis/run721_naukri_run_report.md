# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `721`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-06 07:48:22 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **9** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **4** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **3** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **18** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-051126031791` | **LabourNet** | Backend Engineer AIML , LLM Integration | 3.0-6.0y | 4.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-051126031791) |
| `reco-051126035063` | **Rudder Analytics** | Senior Analytics Engineer - Pune - Rudder Analytics | 3.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126035063) |
| `reco-031126019922` | **Fedex Express Transportation And Supply Chain Serv Ices (i)** | Data Analyst - Customer Retail Analytics | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-031126019922) |
| `reco-041126016282` | **Insurance Company** | Hiring For DATA Analyst - IN TOP Life Insurance Company | 2.0-7.0y | 8.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-041126016282) |
| `reco-051126501856` | **Trigyn Technologies** | Data Analyst | 2.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126501856) |
| `reco-051126024950` | **Wipro** | Financial Data Analyst | 1.0-3.0y | 15.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-051126024950) |
| `reco-051126911059` | **Axa Xl** | CAT Data Analyst | 1.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126911059) |
| `reco-031126020184` | **Roots Recruitment** | Data Analyst | 2.0-5.0y | 8.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-031126020184) |
| `reco-051126031800` | **Jobaaj com** | Artificial Intelligence Engineer | 0-2.0y | 3.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-artificial-intelligence-engineer-jobaaj-com-hyderabad-pune-gurugram-0-to-2-years-051126031800) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-051126502389` | **Bristol Myers Squibb** | Analytical AI Engineer - II | [Apply on Company Site](https://bristolmyerssquibb.wd5.myworkdayjobs.com/en-US/BMS/job/Hyderabad---TS---IN/Analytical-AI-Engineer---II_R1607489-1) |
| `reco-051126501998` | **Rentomojo** | Data Analyst | [Apply on Company Site](https://app.pyjamahr.com/careers?company=Rentomojo&job_id=424698&company_uuid=25D3B9BFB0) |
| `reco-041126502481` | **Premium Aerotec** | Technical Data Analyst - AMM | [Apply on Company Site](https://ag.wd3.myworkdayjobs.com/en-US/Airbus/job/Bangalore-Area/Technical-Data-Analyst---AMM_JR10454634) |
| `reco-051126501583` | **Electronic Arts** | Sr. Data Analyst, Business Strategy - Market Intelligence | [Apply on Company Site](https://jobs.ea.com/en_US/careers/JobDetail/Sr-Data-Analyst-Business-Strategy-Market-Intelligence/216376) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-041126010070` | **IDFC FIRST Bank** | Data Analyst-Data Governance | `already_applied` | Already applied marker observed on verify pass |
| `reco-031126919443` | **CGI** | Data Analyst | `filter_experience` | requires 7.0y > ceiling 3.5y |
| `reco-081026034891` | **Intellect Design Arena** | AIML Engineer | `filter_description` | JD contains blocked term 'expertise in machine learning libraries such as scikit-learn or tensorflow' |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-031126028563` | **Datamatics** | Hiring AI & LLM Engineer with Datamatics For Mumbai/Bangalore | `failed` | Chatbot error: drawer open but no question detected after 3 checks (unknown widget) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-721/074052_439708_AI-Python-Engineer_reco-031126028563_chatbot-error.png) |
| `reco-041126022579` | **Luxoft** | Artificial Intelligence Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-721/074349_566208_AI-Python-Engineer_reco-041126022579_unanswered.png) |
