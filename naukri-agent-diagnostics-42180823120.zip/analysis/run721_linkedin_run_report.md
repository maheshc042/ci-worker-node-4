# 🎯 Application Run Report: Linkedin (AI / Python Engineer)

- **Run ID:** `721`
- **Platform:** Linkedin
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-06 07:58:21 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **1** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **1** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **3** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `linkedin-4486219003` | **Euphoric Thought Technologies Pvt. Ltd.** | Python with Azure - 3-5 Years - Immediate Joiners- Noida Location | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486219003/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4486963386` | **Live Connections** | AI Engineer - Go Lang - PAN INDIA | `filter_experience` | dedicated AI/ML role requires 5.0y > candidate's 3y AI experience (recruiter will reject) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4488010877` | **PranaTree** | LLM ENGINEER – GENERATIVE AI & LARGE LANGUAGE MODELS | `unanswered_question` | LinkedIn screening needs a verified answer | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-721/075814_783394_AI-Python-Engineer_linkedin-4488010877_linkedin-screening-review.png) |
