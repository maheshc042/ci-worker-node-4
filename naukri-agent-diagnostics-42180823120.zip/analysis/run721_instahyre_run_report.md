# 🎯 Application Run Report: Instahyre (Instahyre Unified (AI & Full Stack))

- **Run ID:** `721`
- **Platform:** Instahyre
- **Profile:** Instahyre Unified (AI & Full Stack)
- **Generated At:** 2026-11-06 08:15:21 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **8** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **10** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **18** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `instahyre-449371` | **Valar Ecom** | Full Stack Developer - MERN Stack | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-377967` | **Fragma Data Systems** | Fullstack Developer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449554` | **nCircle Tech** | Python Full Stack Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449893` | **Synchrony** | API Software Development Engineer II | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-446596` | **Kulfi** | Software Development Engineer II | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-446944` | **Doodhvale Farms** | Fullstack Developer (Vibe Coder - AI Claude) | 1.0-1.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-444853` | **1digitalstack** | Backend Engineer | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449537` | **Zensar** | Conversational Systems | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `instahyre-449528` | **VML** | SFCC Frontend Developer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*VML\ \-\ SFCC\ Frontend\ Developer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"VML - SFCC Frontend Developer\"]"))).filter(has=locator("ul[id='job-skills-449528']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449615` | **Sumo Logic** | Software Engineer II | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Sumo\ Logic\ \-\ Software\ Engineer\ II\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Sumo Logic - Software Engineer II\"]"))).filter(has=locator("ul[id='job-skills-449615']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449221` | **Terralogic** | Python and AI/ML Developer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Terralogic\ \-\ Python\ and\ AI/ML\ Developer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Terralogic - Python and AI/ML Developer\"]"))).filter(has=locator("ul[id='job-skills-449221']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-448165` | **Connect and Heal** | QA Engineer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Connect\ and\ Heal\ \-\ QA\ Engineer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Connect and Heal - QA Engineer\"]"))).filter(has=locator("ul[id='job-skills-448165']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-446020` | **Klimb.io** | Junior QA + DevOps Engineer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Klimb\.io\ \-\ Junior\ QA\ \+\ DevOps\ Engineer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Klimb.io - Junior QA + DevOps Engineer\"]"))).filter(has=locator("ul[id='job-skills-446020']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449521` | **Zensar** | Python Developer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Zensar\ \-\ Python\ Developer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Zensar - Python Developer\"]"))).filter(has=locator("ul[id='job-skills-449521']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449624` | **KPMG** | Cloud AI Developer Consultant | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*KPMG\ \-\ Cloud\ AI\ Developer\ Consultant\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"KPMG - Cloud AI Developer Consultant\"]"))).filter(has=locator("ul[id='job-skills-449624']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449679` | **JPMorgan Chase** | Software Engineer II - Payments and Automation | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*JPMorgan\ Chase\ \-\ Software\ Engineer\ II\ \-\ Payments\ and\ Automation\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"JPMorgan Chase - Software Engineer II - Payments and Automation\"]"))).filter(has=locator("ul[id='job-skills-449679']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449644` | **IQ-EQ** | AIML Engineer Digital & AI | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*IQ\-EQ\ \-\ AIML\ Engineer\ Digital\ \&\ AI\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"IQ-EQ - AIML Engineer Digital & AI\"]"))).filter(has=locator("ul[id='job-skills-449644']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-445786` | **Kaleidofin** | UI Developer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Kaleidofin\ \-\ UI\ Developer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Kaleidofin - UI Developer\"]"))).filter(has=locator("ul[id='job-skills-445786']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
