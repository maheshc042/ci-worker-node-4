# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `756`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-10 11:21:35 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **4** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **6** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **12** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-131026015805` | **Businessolver** | Senior Software Engineer- Level 2 | 3.0-8.0y | 15.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-131026015805) |
| `reco-091126006595` | **Infosys** | Fullstack Web Developer(React+Node+AWS) | 1.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-091126006595) |
| `reco-240626026440` | **Medpace Clinical Research India** | Database Programmer - Core Laboratory (Based in Hyderabad) | 1.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-240626026440) |
| `reco-091126004213` | **Fintech Cloud** | Software Tester | 1.0-3.0y | 8.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-091126004213) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-080126024592` | **Medpace Clinical Research India** | Platform Engineer | `already_applied` | Naukri reports this application already exists |
| `reco-091126006922` | **Cognizant** | Automation Test Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `reco-091126006183` | **Edlion Technologies** | Mobile QA Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-210526006951` | **Client of Sampoorna Consultants Pvt. Ltd** | SW Engineer QA | `already_applied` | Already applied marker observed on verify pass |
| `reco-050826036146` | **Hasman Software Solutions** | AI Consultant | `filter_title` | title 'AI Consultant' lacks required role keywords from title_must_include_any |
| `reco-061126020078` | **Will tell later** | Software Tester | `already_applied` | Naukri reports this application already exists |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-091126007021` | **Quest Global** | Software Engineer | `unanswered_question` | Unanswered screening question (submit also failed: could not submit answer for: Please select the city you are currently residing or willing to relocate to) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-10/run-756/111548_960481_Full-Stack-Web-Developer_reco-091126007021_unanswered.png) |
| `reco-091126002874` | **Blupace Hyderabad** | Hiring For QA Engineer | `unanswered_question` | Unanswered screening question (submit also failed: could not submit answer for: Do you have the experience in below industry/ Domain) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-10/run-756/111823_468990_Full-Stack-Web-Developer_reco-091126002874_unanswered.png) |
