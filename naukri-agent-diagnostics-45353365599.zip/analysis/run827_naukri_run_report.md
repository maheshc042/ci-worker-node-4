# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `827`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-24 08:34:03 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **6** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **5** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **5** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **16** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-211126015382` | **Prozo Distribution** | Fullstack Developer (frontend developer) | 3.0-7.0y | 12.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-211126015382) |
| `reco-231126020216` | **AdvaRisk** | Senior Software Engineer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-231126020216) |
| `reco-231126007303` | **Medi Assist** | Qa Automation Testing Engineer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-231126007303) |
| `reco-231126006628` | **Happiest Minds Technologies** | Qa Engineer | 3.0-7.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-231126006628) |
| `reco-231126023292` | **Apidel Technologies** | SDE-I & SDE-II | 3.0-0y | 15.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-231126023292) |
| `reco-201126020724` | **US MNC (analytics)** | Test Engineer + R -- US MNC (analytics) | 3.0-7.0y | 10.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-201126020724) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-231126502618` | **Replicon** | Associate Software Engineer | [Apply on Company Site](https://sjobs.brassring.com/TGnewUI/Search/home/HomeWithPreLoad?partnerid=25397&siteid=5259&PageType=JobDetails&jobid=622669#jobDetails=623705_5259) |
| `reco-211126503908` | **Proffer It Consultancy** | Software Developer - Python_ST | [Apply on Company Site](https://profferit.in/career/?job_id=z5G7h3l6a1kMvyS65NP3c5XTxiMoMmxVW1NxiM3LeEk=) |
| `reco-231126501622` | **b** | Senior Backend Engineer (Custody) | [Apply on Company Site](https://amina.jobs.personio.com/job/2816655) |
| `reco-211126503278` | **Avenoir Innovations** | Software Developer | [Apply on Company Site](https://avenirinnovative.com/careers) |
| `reco-211126502914` | **Pearson** | Staff Software Engineer | [Apply on Company Site](https://pearson.jobs/bangalore-ind/staff-software-engineer/AC8BC9B0852F4BBDB37CBBD29048B7DD/job/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-231126005943` | **Honeywell Aerospace** | Software Developer | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126009342` | **Infinite** | Quality Engineer- Functional Testing | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126005391` | **ESAB India** | Quality Assurance Engineer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `reco-231126004781` | **Naineet Tech** | Software Engineer | `filter_salary` | max offer 4.75 LPA < min 5.0 LPA |
| `reco-201126022871` | **SeaCross Recruitment Services** | Fullstack Developer | `filter_salary` | max offer 4.0 LPA < min 5.0 LPA |
