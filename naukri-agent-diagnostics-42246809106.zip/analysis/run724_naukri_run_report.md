# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `724`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-06 16:15:46 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **3** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **6** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **8** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **5** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **22** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-061126918762` | **Soul Ai** | Python Developer (Mid-Level) | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-python-developer-mid-level-soul-ai-new-delhi-2-to-4-years-061126918762) |
| `reco-061126915861` | **Soul Ai** | Python Developer | 1.0-1.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-python-developer-soul-ai-noida-1-to-3-years-061126915861) |
| `reco-071026940234` | **TP** | Data Analytics Analyst II | 1.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-071026940234) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-051126502066` | **Bristol Myers Squibb** | Data & AI Platform Engineer II, Commercialization | [Apply on Company Site](https://bristolmyerssquibb.wd5.myworkdayjobs.com/en-US/BMS/job/Hyderabad---TS---IN/Data---AI-Platform-Engineer-II--Commercialization_R1607809) |
| `reco-061126500279` | **Arcofintech** | Python Full stack Developer | [Apply on Company Site](https://www.arcofintech.com/careers.html) |
| `reco-061126500110` | **Arcofintech** | AI/ML Engineer | [Apply on Company Site](https://www.arcofintech.com/careers.html) |
| `reco-051126502624` | **EY** | Global Behavioral Analytics & AI Specialist | [Apply on Company Site](https://careers.ey.com/ey/job/Bengaluru-Global-Behavioral-Analytics-&-AI-Specialist-KA-560048/1452752933/) |
| `reco-031126501286` | **Amerisource Bergen** | Data Analyst - Indirect Procurement | [Apply on Company Site](https://www.naukri.com/job-listings-031126501286) |
| `reco-031126501729` | **Eli Lilly And Company** | Data Analyst | [Apply on Company Site](https://lilly.wd115.myworkdayjobs.com/en-US/LLY/job/India-Bangalore/Data-Analyst_R-114271) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-061126916577` | **Soul Ai** | Python Developer (Mid-Level) | `seen_recently` | same company+title already queued this run (Soul Ai / Python Developer (Mid-Level)) |
| `reco-061126918789` | **Soul Ai** | Python Developer (Mid-Level) | `seen_recently` | same company+title already queued this run (Soul Ai / Python Developer (Mid-Level)) |
| `reco-061126916508` | **Soul Ai** | Python Developer | `daily_cap` | company daily cap reached (soul ai, max 2/day) |
| `reco-061126917324` | **Soul Ai** | Python Developer | `daily_cap` | company daily cap reached (soul ai, max 2/day) |
| `reco-061126917978` | **Soul Ai** | Python Developer | `daily_cap` | company daily cap reached (soul ai, max 2/day) |
| `reco-061126917987` | **Soul Ai** | Python Developer | `daily_cap` | company daily cap reached (soul ai, max 2/day) |
| `reco-051126037899` | **Crossing Hurdles** | Data Analyst | `already_applied` | Already applied marker observed on verify pass |
| `reco-031126011968` | **R Systems International** | Automation QA Engineer (WebdriverIO) | `already_applied` | Already applied marker observed on verify pass |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-031126028563` | **Datamatics** | Hiring AI & LLM Engineer with Datamatics For Mumbai/Bangalore | `failed` | Chatbot error: drawer open but no question detected after 3 checks (unknown widget) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/160703_299322_AI-Python-Engineer_reco-031126028563_chatbot-error.png) |
| `reco-021126025271` | **Sony** | Python Data Testing Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/160802_083617_AI-Python-Engineer_reco-021126025271_unanswered.png) |
| `reco-041126022579` | **Luxoft** | Artificial Intelligence Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/160952_262649_AI-Python-Engineer_reco-041126022579_unanswered.png) |
| `reco-051126013372` | **Mantraa Advisory Service** | GTM Automation Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/161051_743936_AI-Python-Engineer_reco-051126013372_unanswered.png) |
| `reco-051126038635` | **Neutrinoiq** | AI Engineer FinTech SaaS | `unanswered_question` | Unanswered screening question (submit also failed: could not submit answer for: Which of the following best describes your long-term career aspiration?) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/161346_499003_AI-Python-Engineer_reco-051126038635_unanswered.png) |
