# 🎯 Application Run Report: Instahyre (Instahyre Unified (AI & Full Stack))

- **Run ID:** `724`
- **Platform:** Instahyre
- **Profile:** Instahyre Unified (AI & Full Stack)
- **Generated At:** 2026-11-06 17:00:55 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **20** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **21** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `instahyre-449999` | **Rocketlane** | AI Engineer | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449970` | **Tennr** | Implementation Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-447193` | **AiPrise** | Software Engineer 2 | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-446647` | **Axi** | Software Development Engineer - 1 | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-429094` | **Prismforce** | Data Scientist - LLM Training and Fine Tuning | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-448283` | **Quant Matrix AI** | AI / ML Engineer | 2.0-2.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-447154` | **Commotion** | AI / ML Engineer | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449523` | **Grapes** | Founding Engineer - Agentic AI | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-446892` | **EngiNeo Solutions** | Oracle AI Agent Studio Engineer | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-447737` | **MagTapp Technologies** | Data Analyst (Mixpanel) | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449403` | **Accelya Group** | Engineer II - Test Automation | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449043` | **Network Marvels** | Software Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-445548` | **Zimperium** | SDET | 1.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449389` | **Nippon Data Systems** | Python Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-427730` | **StockGro** | QA Engineer | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449904` | **Miamin Systems** | Associate Software Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-445528` | **Purplle** | SDE 1 | 1.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449647` | **JPMorgan Chase** | Software Engineer II | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-440866` | **Zed Mobility** | Quality Assurance Engineer II | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-444633` | **Deutsche Telekom Digital Labs** | SDET II | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `instahyre-442724` | **Amazon** | Quality Assurance Analyst | `submission_unconfirmed` | Submission clicked but no Instahyre success confirmation was observed | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/164918_876921_Instahyre-Unified-AI-Full-Stack_instahyre-442724_instahyre-submit-unconfirmed.png) |
