# 🎯 Application Run Report: Cutshort (Cutshort Unified (AI & Full Stack))

- **Run ID:** `724`
- **Platform:** Cutshort
- **Profile:** Cutshort Unified (AI & Full Stack)
- **Generated At:** 2026-11-06 16:33:47 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **1** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `cutshort-XiFbFi5Z` | **CredX** | Frontend Engineer | `failed` | Cutshort could not verify the selected Full Stack Engineer résumé | None |
