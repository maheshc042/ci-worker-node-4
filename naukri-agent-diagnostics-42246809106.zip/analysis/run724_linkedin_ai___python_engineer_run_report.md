# 🎯 Application Run Report: Linkedin (AI / Python Engineer)

- **Run ID:** `724`
- **Platform:** Linkedin
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-06 16:30:00 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **2** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **3** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **4** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **9** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `linkedin-4486218818` | **CodeVyasa** | Agentic AI Developer | 2.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486218818/) |
| `linkedin-4483652208` | **Polestar Analytics** | AI Engineer (Noida) | 3.0-8.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4483652208/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4488132986` | **Applicantz** | Software Engineer – DevOps & Generative AI | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4486962431` | **Daimler Truck Innovation Center India (DTICI)** | AI Specialist | `filter_experience` | dedicated AI/ML role requires 12.0y > candidate's 3y AI experience (recruiter will reject) |
| `linkedin-4486967585` | **Netcore Unbxd** | Platform Artificial Intelligence Engineer | `filter_experience` | dedicated AI/ML role requires 4.0y > candidate's 3y AI experience (recruiter will reject) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4488149500` | **Testsigma** | Applied AI R&D Engineer | `unanswered_question` | LinkedIn screening needs a verified answer | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/162749_820659_AI-Python-Engineer_linkedin-4488149500_linkedin-screening-review.png) |
| `linkedin-4484934350` | **iNextLabs** | Voice AI Engineer | `failed` | LinkedIn did not expose a verifiable application route | None |
| `linkedin-4483862172` | **IndiTech Consulting** | Freelance Amazon Connect AI Engineer | `failed` | LinkedIn did not expose a verifiable application route | None |
| `linkedin-4482624538` | **Papigen** | AI Engineer | `unanswered_question` | LinkedIn screening needs a verified answer | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/162953_364003_AI-Python-Engineer_linkedin-4482624538_linkedin-screening-review.png) |
