# 🎯 Application Run Report: Linkedin (Full Stack / Web Developer)

- **Run ID:** `724`
- **Platform:** Linkedin
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-06 16:24:55 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **5** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **6** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **4** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **15** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `linkedin-4486972623` | **Scoutit** | Full Stack Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486972623/) |
| `linkedin-4486980679` | **Pace Wisdom Solutions** | Javascript Developer | 3.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486980679/) |
| `linkedin-4486234780` | **cmul8** | Forward Deployed Engineer (AI Agents) | - | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486234780/) |
| `linkedin-4486961372` | **Payfinia** | Software Engineer | 2.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486961372/) |
| `linkedin-4486593975` | **Recro** | Javascript Developer | 1.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4486593975/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4486240578` | **Zemoso Technologies** | Python Full Stack Developer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4488147449` | **Applicantz** | QA Automation Tester | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `linkedin-4486963499` | **ITC Infotech** | Full Stack Engineer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4486992315` | **Gravity Infosolutions, Inc.** | QA / Business Analyst - Braze development - Contract | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `linkedin-4488116861` | **Luxoft** | Automation Test Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `linkedin-4486208912` | **airisDATA** | Facets Fullstack developer | `filter_experience` | requires 10.0y > ceiling 3.5y |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `linkedin-4486222438` | **GeoServe** | DevOps Engineer | `unanswered_question` | Easy Apply step blocked (3 questions): Required field unfilled - step=inputs:5::Apply to GeoServe 3/4 pages Additional Questions If selected, how soon can you fill this position (days)?* Invalid input 0/20 0 of 20 characters Are you currently based out of Bangalore?* Yes No How many years of work experience do you have with Amaz | None |
| `linkedin-4486708061` | **Scoutit** | Test Engineer | `failed` | LinkedIn did not expose a verifiable application route | None |
| `linkedin-4486703804` | **Arnifi** | BackEnd Developer | `unanswered_question` | Easy Apply step blocked (6 questions): Required field unfilled - step=inputs:10::Apply to Arnifi 3/4 pages Additional Questions Are you comfortable working in an onsite setting?* Yes No How many years of development experience do you have? * 1/20 1 of 20 characters How many years of experience do you have in Node.js and its frame | None |
| `linkedin-4487749525` | **Media.net** | Software Test Engineer - II ( Mobile Testing - Automation) | NR-2026-0236 | `unanswered_question` | LinkedIn screening needs a verified answer | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/162448_190235_Full-Stack-Web-Developer_linkedin-4487749525_linkedin-screening-review.png) |
