# 🎯 Application Run Report: Wellfound (Wellfound Unified (AI & Full Stack))

- **Run ID:** `724`
- **Platform:** Wellfound
- **Profile:** Wellfound Unified (AI & Full Stack)
- **Generated At:** 2026-11-06 16:39:46 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **1** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `wellfound-5008619` | **drytis.com** | AI Engineer | `failed` | job time cap exceeded (300s) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-724/163940_258499_Wellfound-Unified-AI-Full-Stack_wellfound-5008619_job-time-cap.png) |
