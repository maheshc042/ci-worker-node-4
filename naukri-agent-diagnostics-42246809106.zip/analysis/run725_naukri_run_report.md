# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `725`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-06 17:32:34 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **4** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **17** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **4** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **3** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **28** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-061126010436` | **Softobiz** | AI First Full stack Developer | 2 To 7 Years | Hyderabad | 1.0-8.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-061126010436) |
| `reco-091026912284` | **Capgemini** | AWS Devops CDK Typescript Engineer | 2.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-091026912284) |
| `reco-280926920621` | **Infosys** | Site Reliability Engineer | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-280926920621) |
| `reco-051126024905` | **Tagbin Services** | Junior software Developer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126024905) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-061126502067` | **Charles River** | Full Stack JS Web Framework Developer | [Apply on Company Site](https://jobs.criver.com/job/24111540/full-stack-js-web-framework-developer-remote-remote/) |
| `reco-061126502743` | **Anumana** | Full Stack developer | [Apply on Company Site](https://www.apprenticeshipindia.gov.in/apprenticeship/opportunity-view/6a3e314d843f0c3c39035db3) |
| `reco-061126501941` | **Comaea Consulting** | Software Engineer - Full Stack | [Apply on Company Site](https://comaeaconsulting.zohorecruit.com/jobs/Careers/542409000016678005) |
| `reco-061126501814` | **Leanquality Solutions** | Full Stack Developer | [Apply on Company Site](https://leanqualities.com/career) |
| `reco-061126500859` | **Armis** | Software Engineer - Fullstack | [Apply on Company Site](https://jobs.smartrecruiters.com/ServiceNow/744000159899389) |
| `reco-061126500128` | **Kavya Infoweb** | Full Stack Developer | [Apply on Company Site](https://kavyainfoweb.com/current-openings.html#openings) |
| `reco-041126501685` | **Codemonk** | Site Reliability Engineer (SRE) | [Apply on Company Site](https://app.pyjamahr.com/careers?company=codemon&job_id=424325&company_uuid=F3B7273B62) |
| `reco-051126500594` | **Clobrix Technologies** | DevOps Engineer | [Apply on Company Site](https://clobrix.com/careers) |
| `reco-051126501813` | **Enterprise Bot** | DevOps Engineer | [Apply on Company Site](https://join.com/companies/enterprisebot/16910229-devops-engineer) |
| `reco-061126503053` | **Lastbyte Solutions** | Software Developer (Full-Stack) | [Apply on Company Site](https://www.lastbyte.co.in/careers) |
| `reco-041126503147` | **Platform9 Systems** | DevOps Engineer - 2 | [Apply on Company Site](https://platform9systems.applytojob.com/apply/sWANkoDgm7/Devops-Engineer) |
| `reco-041126501576` | **Gitlab** | Backend Engineer, Authorization | [Apply on Company Site](https://job-boards.greenhouse.io/gitlab/jobs/8905402002) |
| `reco-051126503236` | **Dexaminds** | DevOps Engineer | [Apply on Company Site](https://dexaminds.com/careers/devops-engineer/) |
| `reco-061126914014` | **IBM** | Application Developer-Cloud FullStack | [Apply on Company Site](https://careers.ibm.com/en_US/careers/JobDetail?jobId=138832&source=JB_Naukri) |
| `reco-051126500486` | **DHL Supply Chain** | DevOps Engineer | [Apply on Company Site](https://careers.dhl.com/global/en/job/DPDHGLOBALAV390424ENGLOBALEXTERNAL/Project-Manager-Scrum-Master) |
| `reco-061126500229` | **Ranosys Technologies** | Software Engineer - SFMC | [Apply on Company Site](https://www.ranosys.com/global/about-us/career/current-openings/sfmc-developer-jobs/) |
| `reco-041126500888` | **Q2** | Software Engineer | [Apply on Company Site](https://q2ebanking.wd5.myworkdayjobs.com/en-US/Q2/job/Bangalore-India/Intermediate-Software-Engineer_REQ-12893) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-061126018336` | **Will tell later** | Back End Developer (Node.js) | `filter_experience` | requires 7.0y > ceiling 3.5y |
| `reco-061126025131` | **Perfecter.ai** | Junior Software Engineer, AI-Native Development | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `reco-051126502977` | **Hewlett Packard Enterprise** | Software Development Engineer II | `filter_description` | JD contains blocked term 'registration fee' |
| `reco-050826036146` | **Hasman Software Solutions** | AI Consultant | `filter_title` | title 'AI Consultant' lacks required role keywords from title_must_include_any |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-051126926167` | **Prodapt Solutions** | DevOps Engineer (L2 Support Role) | `failed` | Apply dialog never opened (click had no page effect) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-725/173049_518474_Full-Stack-Web-Developer_reco-051126926167_dialog-never-opened.png) |
| `reco-051026931389` | **Infosys** | AWS Site Reliability Engineer | `failed` | Apply dialog never opened (click had no page effect) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-725/173143_664740_Full-Stack-Web-Developer_reco-051026931389_dialog-never-opened.png) |
| `reco-051126037933` | **Mitratech India** | Software Engineer II | `failed` | Apply dialog never opened (click had no page effect) | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-725/173228_648332_Full-Stack-Web-Developer_reco-051126037933_dialog-never-opened.png) |
