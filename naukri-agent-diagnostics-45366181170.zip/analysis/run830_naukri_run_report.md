# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `830`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-24 10:44:46 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **8** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **3** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **16** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **29** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-241126014780` | **Rankwatch** | Associate Full-Stack Developer(Python + Node.js) | 0-2.0y | 6.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-241126014780) |
| `reco-231126024218` | **IT Giant (Multi National) Pan India** | Gen AI & B Agentic AI / Python Developer / | 3.0-0y | 6.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-231126024218) |
| `reco-231126019643` | **Neurealm** | Neurealm - Job opening - Data Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-231126019643) |
| `reco-231126023911` | **Vishleshan Software** | Python Django Developer | 1.0-4.0y | 3.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-231126023911) |
| `reco-231126016776` | **Cognizant** | Python Developer | 3.0-0y | 10.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-231126016776) |
| `reco-231126024355` | **3i Infotech** | Artificial Intelligence Developer | 2.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-231126024355) |
| `reco-231126022185` | **Netsmart Technologies** | QA Automation Engineer | 3.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-231126022185) |
| `reco-231126022830` | **NovoTree Minds Consulting** | Data Analyst | 2.0-5.0y | 7.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-231126022830) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-231126500524` | **Dentsu Webchutney** | Data Analyst | [Apply on Company Site](https://www.naukri.com/job-listings-231126500524) |
| `reco-211126500507` | **Oceaneering International** | Test Engineer | [Apply on Company Site](https://ebfr.fa.us2.oraclecloud.com/hcmUI/CandidateExperience/en/sites/jobs/job/11686) |
| `reco-201126504539` | **Bootminds System** | Data Governance and Quality Analyst | [Apply on Company Site](https://career.bootminds.com/jobs/data-governance-and-quality-analyst-Bootminds-3152a6) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-241126013984` | **Sveltetech Technologies** | AI Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126005871` | **ClearTrail Technologies** | Agentic AI Engineer | `filter_experience` | dedicated AI/ML role requires 4.0y > candidate's 3y AI experience (recruiter will reject) |
| `reco-231126021935` | **Carelon Global Solutions** | Cloud Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126025867` | **Vtest Software** | SDET | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126009588` | **Provance Business Consulting** | Data Analyst | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126010935` | **Hiring for Top MNC** | Data Analyst | | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126025765` | **protiviti india** | Sr. Consultant - Devops | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126015104` | **Tredence** | Azure Cloud & DevOps Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-171126019246` | **Accelya** | AWS SRE | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `reco-231126003271` | **Bahwan CyberTek** | Data Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-221126002515` | **Cloudkaptan Consultancy Services** | Senior QA Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `reco-201126023177` | **o2h technology** | Data Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126024333` | **3i Infotech** | Devops Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126004672` | **Regalix** | Quality Analyst | `already_applied` | Already applied marker observed on verify pass |
| `reco-231126005391` | **ESAB India** | Quality Assurance Engineer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `reco-190826030284` | **Fatakpay Digital** | Data Analyst | `already_applied` | Naukri reports this application already exists |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-231126005377` | **Clover Infotech** | Devops Engineer | `failed` | Chatbot error: chatbot stalled on the same question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-24/run-830/103232_209630_AI-Python-Engineer_reco-231126005377_chatbot-error.png) |
| `reco-231126006480` | **Renew** | Senior Engineer- Artificial intelligence & Data Science | `failed` | Chatbot error: chatbot stalled on the same question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-24/run-830/104204_067070_AI-Python-Engineer_reco-231126006480_chatbot-error.png) |
