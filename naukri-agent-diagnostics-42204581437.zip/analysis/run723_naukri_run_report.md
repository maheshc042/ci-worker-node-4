# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `723`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-06 11:24:35 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **9** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **18** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **6** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **35** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-051126502791` | **Pixel Values Technolabs** | Full Stack Developer | 1.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126502791) |
| `reco-061126501878` | **Trigyn Technologies** | Full Stack Developer | 2.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-full-stack-developer-trigyn-technologies-new-delhi-2-to-3-years-061126501878) |
| `reco-051126037904` | **Puretech Internet** | Full Stack Engineer (AI-native) | 3.0-5.0y | 8.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-051126037904) |
| `reco-051026931805` | **Infosys** | Full Stack Developer (React, Node.js, AWS, DevOps) | 3.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051026931805) |
| `reco-051126502818` | **Pixel Values Technolabs** | Frontend Developer | 1.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126502818) |
| `reco-081026042298` | **Intellect Design Arena** | Devops Engineer | 3.0-5.0y | 3.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-081026042298) |
| `reco-051126027311` | **Coresight Research, Inc.** | Fullstack Engineer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-051126027311) |
| `reco-091026014368` | **Nobl Q** | Devops Engineer opening in chennai | 2.0-0y | 5.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-091026014368) |
| `reco-091026912794` | **Equinix** | Staff Software Engineer | Looker Developer | 3.0-8.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-091026912794) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-041126502100` | **Aziro** | Backend Developer | [Apply on Company Site](https://aziro.mynexthire.com/employer/jobs) |
| `reco-051126503049` | **Microsive** | AI Full-Stack Developer | [Apply on Company Site](https://www.microsive.com/careers/ai-full-stack-developer) |
| `reco-051126501535` | **Cisco** | Software Engineer - Backend, Python/Go, Distributed Systems, Cloud | [Apply on Company Site](https://cisco.wd5.myworkdayjobs.com/en-US/Cisco_Careers/job/Bangalore-India/Software-Engineer---Backend--Python-Go--Distributed-Systems--Cloud--2---4-Years_2027380?locations=8676de3331b41001f4eaac80a6280000&locations=6bed8334bf4b1001f4f15a1f787a0000&locations=8676de3331b41001f4f96625fdde0000&locations=ef8a5a22403d1001f4fde228ba110000&locations=026fa05becb01001f506953e0df00000&locations=3dbd26f9e73e1001f4d59df763f20000&locations=662e524adea41001f4d0bd5a1ddd0000&locations=0696c83bbe641001f4f0800dae0d0000) |
| `reco-051126502767` | **Digiink Solutions** | Frontend Developer | [Apply on Company Site](https://www.digiinksolutions.com/careers) |
| `reco-051126501221` | **Dexaminds** | ReactJS Developer | [Apply on Company Site](https://dexaminds.com/careers/reactjs-developer/) |
| `reco-051126926477` | **Optum** | Full Stack Engineer | [Apply on Company Site](https://www.naukri.com/job-listings-051126926477) |
| `reco-051126501193` | **Salmon Commerce** | SFCC Frontend Developer | [Apply on Company Site](https://www.vml.com/careers/job/8923142002?gh_jid=8923142002) |
| `reco-061126502236` | **Salesforce** | Full-Stack Developer - AI-Native Engineering | [Apply on Company Site](https://salesforce.wd12.myworkdayjobs.com/en-US/External_Career_Site/job/India---Bangalore/Full-Stack-Developer---AI-Native-Engineering_JR359537) |
| `reco-051126501716` | **The Networker** | Platform Engineer, Python | [Apply on Company Site](https://ebay.wd5.myworkdayjobs.com/en-US/apply/job/Bengaluru-India/Platform-Engineer--Python_R0076563-1) |
| `reco-051126501093` | **Dentsu Webchutney** | Sr Backend Developer | [Apply on Company Site](https://dentsuaegis.wd3.myworkdayjobs.com/en-US/DAN_GLOBAL/job/Mumbai/Senior-Backend-Developer_R1131895) |
| `reco-051126500802` | **Ariane Fine Porcelain** | Sr Web Developer | [Apply on Company Site](https://app.ismartrecruit.com/jobDescription?x=E7pdW1iZXJ0b2NlcmFtaWNzLmNvbV80Ml9QUk9NT1RFVVJMX2VuQ9e) |
| `reco-051126501270` | **Vaani Research Labs** | Backend Engineer - Vaani Developer Platform | [Apply on Company Site](https://vaaniresearch.com/team.html) |
| `reco-051126502690` | **Sconto** | Engineering - Frontend Professional | [Apply on Company Site](https://sconto.ai/career) |
| `reco-041126501485` | **Cisco** | Software Test Automation Engineer | [Apply on Company Site](https://cisco.wd5.myworkdayjobs.com/en-US/Cisco_Careers/job/Bangalore-India/Software-Test-Automation-Engineer_2029808?locations=8676de3331b41001f4eaac80a6280000&locations=6bed8334bf4b1001f4f15a1f787a0000&locations=8676de3331b41001f4f96625fdde0000&locations=ef8a5a22403d1001f4fde228ba110000&locations=026fa05becb01001f506953e0df00000&locations=3dbd26f9e73e1001f4d59df763f20000&locations=662e524adea41001f4d0bd5a1ddd0000&locations=0696c83bbe641001f4f0800dae0d0000) |
| `reco-051126500205` | **Jefferies Financial Group** | Associate - SRE - Platform Engineering | [Apply on Company Site](https://hdid.fa.us2.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1/job/5050) |
| `reco-051126911234` | **Vanguard** | Application Engineer - II Data - ESG/Reference GIFS | [Apply on Company Site](https://vanguard.wd5.myworkdayjobs.com/en-US/vanguard_external/job/Hyderabad-India/Application-Engineer---II-Data---ESG-Reference-GIFS_182443) |
| `reco-051126934130` | **Fujitsu** | Application Developer_MFT Engineer | [Apply on Company Site](https://www.jobs.global.fujitsu.com/job/Application-Developer_MFT-Engineer/14366-en_US?utm_source=Naukri) |
| `reco-041126502330` | **WEX** | Software Development Engineer 1 | [Apply on Company Site](https://wexinc.wd5.myworkdayjobs.com/en-US/WEXInc/job/India---Bangalore-Office/Software-Development-Engineer-1_R22749) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-140726021062` | **Insightstap Solutions** | Senior Backend Developer (Node.js) | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `reco-061126013144` | **Digient Technologies** | Software Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-051126037563` | **Nxtwave Disruptive Technologies (Hiring for a Client)** | Back End Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-051126502978` | **Hewlett Packard Enterprise** | Software Development Engineer II - AI and Optimization | `filter_description` | JD contains blocked term 'registration fee' |
| `reco-041126025427` | **GreyOrange** | Site Reliability Engineer I | `already_applied` | Already applied marker observed on verify pass |
| `reco-050826036146` | **Hasman Software Solutions** | AI Consultant | `filter_title` | title 'AI Consultant' lacks required role keywords from title_must_include_any |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-051126014304` | **Crisil** | Adobe AEM Front End Developer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-723/111452_000111_Full-Stack-Web-Developer_reco-051126014304_unanswered.png) |
| `reco-051126037933` | **Mitratech India** | Software Engineer II | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-06/run-723/112259_461057_Full-Stack-Web-Developer_reco-051126037933_unanswered.png) |
