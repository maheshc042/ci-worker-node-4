# 🎯 Application Run Report: Instahyre (Instahyre Unified (AI & Full Stack))

- **Run ID:** `717`
- **Platform:** Instahyre
- **Profile:** Instahyre Unified (AI & Full Stack)
- **Generated At:** 2026-11-06 06:16:43 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **9** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **16** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **8** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **33** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `instahyre-449842` | **Kapiva** | Full Stack Engineer II | 2.0-3.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-428290` | **Stitch** | Frontend Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-427967` | **dataFloat** | Full Stack Developer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-449330` | **Cogniify** | Full Stack AI Software Engineer | 3.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-448643` | **MathCo** | Full Stack Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-448891` | **GrowthArc** | AI Fullstack Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-407563` | **Arctic Wolf** | Frontend React.js Developer | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-424674` | **Accolite Digital** | Frontend Developer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |
| `instahyre-401111` | **Sprinklr** | Principle Frontend Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.instahyre.com/candidate/opportunities/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `instahyre-441236` | **Roche** | Software Engineer - Fullstack | `filter_experience` | requires 7.0y > ceiling 3.5y |
| `instahyre-436194` | **Accellor** | Fullstack Developer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `instahyre-410250` | **House of Models** | Node.js Fullstack Developer | `filter_experience` | requires 8.0y > ceiling 3.5y |
| `instahyre-420251` | **Newpage Solutions** | Full Stack Developer - GEN AI | `filter_experience` | requires 7.0y > ceiling 3.5y |
| `instahyre-434645` | **Contrails AI** | Fullstack Engineer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `instahyre-449912` | **Accenture** | Full Stack Engineering Consultant | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `instahyre-449954` | **Accenture** | Full Stack Engineering Consultant | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `instahyre-433855` | **ConveGenius** | Fullstack Engineer (Python & React.js) | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `instahyre-432726` | **Pierian Services** | Mern + AI Consultant | `filter_experience` | requires 9.0y > ceiling 3.5y |
| `instahyre-428315` | **Stitch** | Frontend Engineer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `instahyre-444430` | **Syfe** | Frontend Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `instahyre-418228` | **Juliet AI** | Fullstack Engineer - AI Coding Platform | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `instahyre-444290` | **Accenture** | Software Engineer - React.js | `filter_experience` | requires 7.5y > ceiling 3.5y |
| `instahyre-424111` | **OneShot AI** | Node.js Developer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `instahyre-428586` | **ACL Digital** | Node.js Developer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `instahyre-437910` | **G2** | Fullsatck AI Engineer | `filter_experience` | dedicated AI/ML role requires 5.0y > candidate's 3y AI experience (recruiter will reject) |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `instahyre-436148` | **Rekise Marine** | Fullstack Engineer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Rekise\ Marine\ \-\ Fullstack\ Engineer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Rekise Marine - Fullstack Engineer\"]"))).filter(has=locator("ul[id='job-skills-436148']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-428287` | **Marseer AI** | Fullstack Developer - AI | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Marseer\ AI\ \-\ Fullstack\ Developer\ \-\ AI\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Marseer AI - Fullstack Developer - AI\"]"))).filter(has=locator("ul[id='job-skills-428287']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-401137` | **Spry** | Frontend Engineer - React.js | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Spry\ \-\ Frontend\ Engineer\ \-\ React\.js\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Spry - Frontend Engineer - React.js\"]"))).filter(has=locator("ul[id='job-skills-401137']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-217001` | **QueueBuster** | Frontend Developer - React.js | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*QueueBuster\ \-\ Frontend\ Developer\ \-\ React\.js\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"QueueBuster - Frontend Developer - React.js\"]"))).filter(has=locator("ul[id='job-skills-217001']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-402260` | **Accolite Digital** | React.js Developer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Accolite\ Digital\ \-\ React\.js\ Developer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Accolite Digital - React.js Developer\"]"))).filter(has=locator("ul[id='job-skills-402260']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-425433` | **Kiwi General Insurance** | Backend Developer - Node.js | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Kiwi\ General\ Insurance\ \-\ Backend\ Developer\ \-\ Node\.js\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Kiwi General Insurance - Backend Developer - Node.js\"]"))).filter(has=locator("ul[id='job-skills-425433']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-427477` | **ACL Digital** | Node.js Developer | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*ACL\ Digital\ \-\ Node\.js\ Developer\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"ACL Digital - Node.js Developer\"]"))).filter(has=locator("ul[id='job-skills-427477']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
| `instahyre-449827` | **Zensar** | Quality Assurance Analyst | `failed` | Instahyre opportunity did not open: Locator.click: Timeout 4000ms exceeded.
Call log:
  - waiting for locator("div.employer-row").filter(has=locator("div.employer-job-name .company-name").filter(has_text=re.compile(r"^\s*Zensar\ \-\ Quality\ Assurance\ Analyst\s*$", re.IGNORECASE)).or_(locator("div.employer-job-name[title=\"Zensar - Quality Assurance Analyst\"]"))).filter(has=locator("ul[id='job-skills-449827']")).locator("a#employer-profile-opportunity[ng-click='openApplyModal(opp)']").first
    - locator resolved to <a class="row text-link" ng-click="openApplyModal(opp)" id="employer-profile-opportunity">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is outside of the viewport
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
 | None |
