# 🎯 Application Run Report: Naukri (AI / Python Engineer)

- **Run ID:** `789`
- **Platform:** Naukri
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-15 16:04:53 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **5** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **4** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **8** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **2** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **19** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-131126920298` | **Platinus Technologies Pvt Ltd** | Python Developer-US shift-Full time | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-131126920298) |
| `reco-121126918929` | **Twixor** | DevOps Engineer | 3.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-121126918929) |
| `reco-210926922881` | **Infosys** | Devops Engineer (Git Hub Actions/Git Labs CICD) | 2.0-6.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-210926922881) |
| `reco-121126925983` | **F5** | Cloud Infrastructure / Platform Engineer | 3.0-7.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-121126925983) |
| `reco-121126919076` | **Deepspatial** | Azure DevOps Engineer | 2.0-5.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-121126919076) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-131126501191` | **Sia Partners** | Agentic AI Builder expert | [Apply on Company Site](https://jobs.smartrecruiters.com/Sia/744000161263709) |
| `reco-131126503595` | **Birlasoft** | GEN AI Developer | [Apply on Company Site](https://jobs.birlasoft.com/job/Chennai-GEN-AI-Developer-INDI/61452244) |
| `reco-131126500690` | **Calpine Group** | AI Engineer (AI-2) | [Apply on Company Site](https://www.calpinetech.com/career) |
| `reco-131126503128` | **Cyncly** | Software Engineer - Agentic Flows | [Apply on Company Site](https://fa-ewdg-saasfaprod1.fa.ocs.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CynclyJobs/job/2772) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-131126920302` | **Platinus Technologies Pvt Ltd** | Python Developer-US shift-Full time | `seen_recently` | same company+title already queued this run (Platinus Technologies Pvt Ltd / Python Developer-US shift-Full time) |
| `reco-131126920300` | **Platinus Technologies Pvt Ltd** | Python Developer-US shift-Full time | `seen_recently` | same company+title already queued this run (Platinus Technologies Pvt Ltd / Python Developer-US shift-Full time) |
| `reco-131126920294` | **Platinus Technologies Pvt Ltd** | Python Developer-US shift-Full time | `seen_recently` | same company+title already queued this run (Platinus Technologies Pvt Ltd / Python Developer-US shift-Full time) |
| `reco-131126029534` | **GreyOrange** | DevOps Engineer I | `already_applied` | Already applied marker observed on verify pass |
| `reco-131126010609` | **Backbase** | System Engineer (DevOps) | `already_applied` | Already applied marker observed on verify pass |
| `reco-121126011536` | **Kiya.ai** | Devops Engineer ( Openshift & kubernetes mandate )_2 To 5 years | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `reco-131126033607` | **Hiring for Infosys** | Infosys Hiring For Gen AI Engineer | `already_applied` | Already applied marker observed on verify pass |
| `reco-131126032606` | **Quest Global** | Devops Engineer-Quest Global-Trivendrum | `already_applied` | Already applied marker observed on verify pass |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-131026012648` | **Omm It Solutions** | Oracle Cloud Infrastructure (OCI) DevOps Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-789/155856_182567_AI-Python-Engineer_reco-131026012648_unanswered.png) |
| `reco-121126034759` | **Virtusa** | Azure Cloud Engineer | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-15/run-789/160053_393858_AI-Python-Engineer_reco-121126034759_unanswered.png) |
