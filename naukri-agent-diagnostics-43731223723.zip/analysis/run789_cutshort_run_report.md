# 🎯 Application Run Report: Cutshort (Cutshort Unified (AI & Full Stack))

- **Run ID:** `789`
- **Platform:** Cutshort
- **Profile:** Cutshort Unified (AI & Full Stack)
- **Generated At:** 2026-11-15 16:15:46 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **5** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **1** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **6** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `cutshort-IGxTMLzy` | **Euphoric Thought Technologies** | MERN Developer (Contract Base Immediate joiner ) | 3.0-5.0y | 8.0 LPA | 1-click | [View Posting](https://cutshort.io/job/MERN-Developer-Contract-Base-Immediate-joiner-Bengaluru-Bangalore-Noida-Euphoric-Thought-Technologies-IGxTMLzy) |
| `cutshort-P3uS7fK3` | **Euphoric Thought Technologies** | MERN Stack Developer | 3.0-3.0y | 6.0 LPA | 1-click | [View Posting](https://cutshort.io/job/MERN-Stack-Developer-Bengaluru-Bangalore-Euphoric-Thought-Technologies-P3uS7fK3) |
| `cutshort-l0pPTpn6` | **Talent Teams** | Software Developer | 2.0-5.0y | 4.0 LPA | 1-click | [View Posting](https://cutshort.io/job/Software-Developer-Talent-Teams-l0pPTpn6) |
| `cutshort-Ru2XY8O9` | **Cybotrix Technologies Pvt Ltd** | AI Adoption specialist/AI Consultant | 2.0-0y | 10.0 LPA | 1-click | [View Posting](https://cutshort.io/job/AI-Adoption-specialist-AI-Consultant-Ahmedabad-Cybotrix-Technologies-Pvt-Ltd-Ru2XY8O9) |
| `cutshort-TokFxfrA` | **Cglia Solutions LLP** | Software Engineer - Angular | 3.0-4.0y | 4.0 LPA | 1-click | [View Posting](https://cutshort.io/job/Software-Engineer-Angular-Hyderabad-Cglia-Solutions-LLP--TokFxfrA) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `cutshort-E5o6r0n1` | **Euphoric Thought Technologies** | Python with Azure | `daily_cap` | company daily cap reached (euphoric thought, max 2/day) |
