# 🎯 Application Run Report: Naukri (Full Stack / Web Developer)

- **Run ID:** `703`
- **Platform:** Naukri
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-05 10:59:52 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **3** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Enqueued** | **1** | 🌐 Handed Off | Career site links enqueued to Sidekick external queue |
| **Skipped** | **4** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **1** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **9** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `reco-031126913608` | **Cornerstone** | SDET | 2.0-4.0y | Not Disclosed | 1-click | [View Posting](https://www.naukri.com/job-listings-031126913608) |
| `reco-021126024868` | **E4 Software Services** | Database Automation Tester | 3.0-6.0y | 4.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-021126024868) |
| `reco-040826008571` | **Smart Ims** | Site Reliability Engineer | 3.0-5.0y | 7.0 LPA | 1-click | [View Posting](https://www.naukri.com/job-listings-040826008571) |

## 🌐 External Applications Routed to Sidekick

| Job ID | Company | Title | External Career Portal Link |
|:---|:---|:---|:---|
| `reco-041126502221` | **West Pharmaceutical Services** | Software Engineer, D&T, MS Azure/Cloud | [Apply on Company Site](https://careers.westpharma.com/job/Bengaluru-Software-Engineer%2C-D&T%2C-MS-AzureCloud-KA/1453736133) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `reco-051126015377` | **Datawrkz** | Front End Developer | `already_applied` | Already applied marker observed on verify pass |
| `reco-041126500244` | **Happiest Minds Technologies** | Sr TEST ENGINEER - Automation testing | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `reco-021126008380` | **Side** | Automation Engineer/SDET (Contract - 1 month) | `already_applied` | Already applied marker observed on verify pass |
| `reco-050826036146` | **Hasman Software Solutions** | AI Consultant | `filter_title` | title 'AI Consultant' lacks required role keywords from title_must_include_any |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `reco-031126011968` | **R Systems International** | Automation QA Engineer (WebdriverIO) | `unanswered_question` | Unanswered screening question | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-703/105658_631127_Full-Stack-Web-Developer_reco-031126011968_unanswered.png) |
