# 🎯 Application Run Report: Linkedin (AI / Python Engineer)

- **Run ID:** `828`
- **Platform:** Linkedin
- **Profile:** AI / Python Engineer
- **Generated At:** 2026-11-24 09:52:41 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **2** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **6** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **8** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `linkedin-4494100566` | **Dar** | Automation Specialist (Python Developer) | 2.0-2.0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4494100566/) |
| `linkedin-4492685277` | **HCLTech** | Walk In - Gen AI Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4492685277/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4493993571` | **Innova ESI** | Associate Data Scientist – AI/ML/LLM | `filter_experience` | dedicated AI/ML role requires 6.0y > candidate's 3y AI experience (recruiter will reject) |
| `linkedin-4493658668` | **HCLSoftware** | Python Developer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4492601733` | **HCLTech** | Gen AI | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4494017489` | **DBiz.ai** | Microsoft Power Platform Developer | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `linkedin-4492669551` | **CodeVyasa** | Data Engineer | `filter_experience` | requires 8.0y > ceiling 3.5y |
| `linkedin-4494102491` | **CoffeeBeans** | Fullstack AI Engineer | `filter_experience` | requires 4.0y > ceiling 3.5y |
