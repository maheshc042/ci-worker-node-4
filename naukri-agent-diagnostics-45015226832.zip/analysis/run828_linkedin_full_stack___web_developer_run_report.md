# 🎯 Application Run Report: Linkedin (Full Stack / Web Developer)

- **Run ID:** `828`
- **Platform:** Linkedin
- **Profile:** Full Stack / Web Developer
- **Generated At:** 2026-11-24 09:46:21 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **7** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **12** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **0** | ✨ Clean | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **19** | | |

## ✅ Direct Applications Submitted

| Job ID | Company | Title | Exp Required | Salary | Screening Qs | Link |
|:---|:---|:---|:---:|:---:|:---:|:---|
| `linkedin-4492689266` | **Sosuv** | Full Stack Developer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4492689266/) |
| `linkedin-4469915914` | **Radancy** | QA Engineer | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4469915914/) |
| `linkedin-4494328163` | **World Wide Technology** | Cloud Platform SRE Engineer - (Jr - Mid level) - Bengaluru - Hybrid | - | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4494328163/) |
| `linkedin-4492671981` | **Connect Career** | Software Test Engineer | 2.0-0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4492671981/) |
| `linkedin-4494102209` | **TekIT Software Solutions Pvt. Ltd. (India & USA)** | Network Test Engineer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4494102209/) |
| `linkedin-4494320602` | **Isomorph AI** | Forward Deployed Engineer | - | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4494320602/) |
| `linkedin-4473652070` | **Tipstat®** | Product Engineer | 3.0-0y | Not Disclosed | 1-click | [View Posting](https://www.linkedin.com/jobs/view/4473652070/) |

## ⏭️ Skipped Roles (Intentional Business Logic)

| Job ID | Company | Title | Skip Reason | Detail |
|:---|:---|:---|:---|:---|
| `linkedin-4493982041` | **Trigent Software - Professional Services** | Automation Test Engineer / SDET (JavaScript – Playwright / WebdriverIO / Cypress) | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4493999528` | **Innova ESI** | Python + AWS Developer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4492681657` | **Adorix IT Services** | Full Stack Developer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4494306698` | **ITC Infotech** | Test Automation Specialist | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4493984929` | **Ascendion** | Quality Assurance Automation Engineer with Playwright | `filter_experience` | requires 8.0y > ceiling 3.5y |
| `linkedin-4493767586` | **Neev** | Azure Devops Engineer (Immediate to 20 Days Notice Period) | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4493996328` | **TekIT Software Solutions Pvt. Ltd. (India & USA)** | Kubernetes Administrator (DevOps Engineer) | `filter_experience` | requires 4.0y > ceiling 3.5y |
| `linkedin-4494301926` | **propelld** | Quality Analyst | `low_match_score` | No candidate-stack overlap in title/JD |
| `linkedin-4494313566` | **Dentsu Global Services** | Back End Developer | `filter_experience` | requires 6.0y > ceiling 3.5y |
| `linkedin-4492646666` | **ITCO Solutions, Inc.** | Python engineer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4494325082` | **Walnutt** | Python Fullstack Engineer | `filter_experience` | requires 5.0y > ceiling 3.5y |
| `linkedin-4493994701` | **slice** | Site Reliability Engineer - 3 | `filter_experience` | requires 6.0y > ceiling 3.5y |
