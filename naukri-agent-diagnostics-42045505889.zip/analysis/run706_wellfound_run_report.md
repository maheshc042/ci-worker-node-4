# 🎯 Application Run Report: Wellfound (Wellfound Unified (AI & Full Stack))

- **Run ID:** `706`
- **Platform:** Wellfound
- **Profile:** Wellfound Unified (AI & Full Stack)
- **Generated At:** 2026-11-05 14:35:07 UTC

## 📊 Executive Overview

| Category | Count | Status | Notes |
|:---|:---:|:---:|:---|
| **Direct Applied** | **0** | ✅ Success | Completed directly via 1-click or screening chatbot |
| **External Routes** | **0** | 🌐 Company-site route | Check outbox records separately for queueing and delivery |
| **Skipped** | **0** | ⏭️ Intentional | Repost collapsed, daily cap, stale redirect, or JD experience mismatch |
| **Failures / Review** | **4** | 🚨 Review | True errors, timeouts, or unanswered mandatory questions |
| **Total Processed** | **4** | | |

## 🚨 Failures & Blockers (Action Required)

| Job ID | Company | Title | Status | Error Detail | Screenshot / Artifact |
|:---|:---|:---|:---:|:---|:---|
| `wellfound-4967229` | **The Growth Square** | Senior MERN Stack Developer | `submission_unconfirmed` | No success confirmation received | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-706/143256_566112_Wellfound-Unified-AI-Full-Stack_wellfound-4967229_wellfound-submit-unconfirmed.png) |
| `wellfound-4995165` | **Double AI** | AI Agents and Automation Engineer | `submission_unconfirmed` | No success confirmation received | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-706/143336_799602_Wellfound-Unified-AI-Full-Stack_wellfound-4995165_wellfound-submit-unconfirmed.png) |
| `wellfound-3898359` | **Sagepilot AI** | Voice Engineer | `submission_unconfirmed` | No success confirmation received | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-706/143426_383815_Wellfound-Unified-AI-Full-Stack_wellfound-3898359_wellfound-submit-unconfirmed.png) |
| `wellfound-4901453` | **FractionAI** | AI Deployment Specialist (DS, DE & SWE) | `submission_unconfirmed` | No success confirmation received | [Screenshot](/home/runner/work/ci-worker-node-4/ci-worker-node-4/artifacts/2026-11-05/run-706/143503_951557_Wellfound-Unified-AI-Full-Stack_wellfound-4901453_wellfound-submit-unconfirmed.png) |
